/**
 * Shared UniMeet configuration, catalogs, and optional clearly-labeled sample event presets.
 * Zero hardcoded localhost/REST/WebSocket endpoints — all data communicates via Firebase SDK.
 */

export const EVENT_CATEGORIES = [
  "Concert",
  "Festival",
  "Party",
  "Theatre",
  "Cinema",
  "Stand-up Comedy",
  "Sports",
  "Gaming",
  "Board Games",
  "Campus Meetup",
  "Art & Culture",
];

export const INTERESTS_CATALOG = [
  { id: "indie_music", name: "Indie Music", category: "Music" },
  { id: "electronic_dj", name: "Electronic & DJ Sets", category: "Music" },
  { id: "jazz_acoustic", name: "Jazz & Acoustic", category: "Music" },
  { id: "festival_culture", name: "Festivals", category: "Music" },
  { id: "indie_cinema", name: "Indie Cinema", category: "Screen & Stage" },
  { id: "theatre_drama", name: "Theatre & Drama", category: "Screen & Stage" },
  { id: "standup_comedy", name: "Stand-up Comedy", category: "Screen & Stage" },
  { id: "board_games", name: "Board Games", category: "Games" },
  { id: "esports_gaming", name: "Gaming & Esports", category: "Games" },
  { id: "coffee_walks", name: "Coffee & City Walks", category: "Social" },
  { id: "campus_clubs", name: "Campus Meetups", category: "Social" },
  { id: "photography", name: "Photography", category: "Creative" },
  { id: "art_galleries", name: "Art Galleries", category: "Creative" },
  { id: "running_cycling", name: "Running & Cycling", category: "Active" },
  { id: "bouldering", name: "Bouldering & Hiking", category: "Active" },
  { id: "foodie_spots", name: "Street Food & Markets", category: "Food" },
];

export const SUGGESTED_HOBBIES = [
  "Photography",
  "Bouldering",
  "Board Games",
  "Specialty Coffee",
  "Guitar",
  "Cycling",
  "Cooking",
  "Sketching",
  "Hiking",
  "Vinyl Collecting",
  "Film Making",
  "Running",
  "Chess",
  "Yoga",
  "Reading",
  "Baking",
  "3D Printing",
  "Gardening",
  "Table Tennis",
  "Volunteering",
];

export const EVENT_IMAGE_PRESETS = [
  { label: "Indie Concert", url: "assets/images/concert-preset.svg" },
  { label: "Cinema & Film Club", url: "assets/images/cinema-preset.svg" },
  { label: "Board Games & Cafe", url: "assets/images/games-preset.svg" },
  { label: "Campus Meetup", url: "assets/images/campus-preset.svg" },
];

export const REPORT_REASONS = [
  { value: "harassment", label: "Harassment or abusive messages" },
  { value: "spam", label: "Spam or unwanted promotion" },
  { value: "inappropriate_content", label: "Inappropriate profile or event content" },
  { value: "fake_profile", label: "Fake or impersonated student profile" },
  { value: "safety_concern", label: "Real-world meetup safety concern" },
  { value: "other", label: "Other moderation issue" },
];

export const SAMPLE_EVENTS_TEMPLATES = [
  {
    title: "Timisoara Indie Acoustic Night",
    category: "Concert",
    location: "Bastion Theresia Courtyard",
    city: "Timisoara",
    university: "Politehnica University of Timisoara",
    description: "Casual acoustic live sets by student bands under the Bastion arches. Great spot to meet music fans before the show.",
    imageUrl: "assets/images/concert-preset.svg",
    maximumParticipants: 35,
    daysAhead: 3,
    hour: 20,
  },
  {
    title: "European Indie Film Screening & Discussion",
    category: "Cinema",
    location: "Cinema Victoria",
    city: "Timisoara",
    university: "West University of Timisoara",
    description: "Evening screening followed by an informal coffee chat in Piata Unirii about cinematography and student film projects.",
    imageUrl: "assets/images/cinema-preset.svg",
    maximumParticipants: 20,
    daysAhead: 5,
    hour: 19,
  },
  {
    title: "Campus Board Games & Specialty Coffee",
    category: "Board Games",
    location: "Student Complex Cafe",
    city: "Timisoara",
    university: "Politehnica University of Timisoara",
    description: "Bring friends or join solo — Catan, Codenames, Dixit, and Azul tables ready for newcomers.",
    imageUrl: "assets/images/games-preset.svg",
    maximumParticipants: 16,
    daysAhead: 2,
    hour: 18,
  },
  {
    title: "Newcomers Campus Coffee Walk",
    category: "Campus Meetup",
    location: "Piata Victoriei Fountain",
    city: "Timisoara",
    university: "West University of Timisoara",
    description: "Friendly sunset walk along the Bega canal for international, Erasmus, and local students looking to expand their circle.",
    imageUrl: "assets/images/campus-preset.svg",
    maximumParticipants: 25,
    daysAhead: 4,
    hour: 17,
  },
];

export const DEMO_ACCOUNT = {
  email: "demo@unimeet.app",
  password: "DemoUser123!",
  first_name: "Alex",
  last_name: "Popescu",
  username: "demo_alex",
  age: 21,
  university: "Politehnica University of Timisoara",
  city: "Timisoara",
  bio: "Computer Science student always up for indie concerts, outdoor cinema, board games, and specialty coffee.",
  interests: ["Indie Music", "Indie Cinema", "Board Games", "Coffee & City Walks"],
  hobbies: ["Photography", "Board Games", "Specialty Coffee"],
  likedCategories: ["Concert", "Cinema", "Board Games", "Campus Meetup"],
};

export const CONFIG = {
  DEMO_ACCOUNT,
  EVENT_CATEGORIES,
  INTERESTS_CATALOG,
  SUGGESTED_HOBBIES,
  EVENT_IMAGE_PRESETS,
  REPORT_REASONS,
  SAMPLE_EVENTS_TEMPLATES,
};
